#=====================================#
POOL-LOOP: hecho en Python 3.5
Fecha de Creaci�n: 23 de Mayo de 2016
Autor: Enrique Jos� Par�s C�rdenas
#=====================================#

Pool-Loop es un videojuego que simula un juego de billar, de un jugador.

Reglas de juego:
- El objetivo del juego es introducir todas las bolas en los hoyos de la mesa, en orden ascendente, antes de que se te acaben los golpes m�ximos que puedes dar.
- Acumular�s puntos de acuerdo a las bolas que introduzcas: introducir la bola 9 de dar� 9 puntos. IMPORTANTE: la bola que introduzcas tiene que ser la bola con el menor n�mero
  en la mesa. El primer objetivo es entonces la bola 1, despu�s de esa la bola 2, y as� en adelante. Si introduces una bola que no era la que segu�a en el orden, tu puntaje no se ver�   afectado, reduciendo entonces tu puntaje total.
- No debes introducir la bola blanca en ning�n hoyo. Si ocurre, ser� regresada a la mesa, y la �ltima bola que hayas introducido tambi�n ser� regresada a la mesa en una posici�n aleatoria.   Tu puntaje ser� reducido por el n�mero de esa bola que haya sido regresada a la mesa.

Controles:
   - 'a' y 'd': te permiten rotar hacia la izquierda o derecha, respectivamente, el �ngulo de tu tiro.
   - 'j': confirmar la direcci�n de tu tiro, y comenzar a cargar la potencia. Presionar de nuevo para detener la barra en el momento que refleje la potencia deseada (barra m�s llena significa m�s potencia).
   - Bot�n 'Guardar juego': puedes presionar este bot�n cuando el juego est� esperando tu siguiente tiro para guardar el juego, y poder resumirlo cuando vuelvas a empzar el juego con el bot�n "Cargar juego".